package com.example.overlayhud;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
public class OverlayHudService extends Service {
    private static final String CH="overlay_hud";
    private static WindowManager wm;
    private static FrameLayout root;
    private static boolean visible=true;
    @Override public void onCreate(){
        super.onCreate();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        root=new FrameLayout(this);
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT, Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START;
        wm.addView(root,lp);
        Preset p = PresetManager.load(this,"Default");
        // Add panel first (layer 1)
        for (Preset.Button b:p.buttons){
            if ("panel".equals(b.type)){
                MousePanelView mv=new MousePanelView(this,b,false);
                root.addView(mv, new FrameLayout.LayoutParams(b.size,b.size));
                mv.setX(b.x); mv.setY(b.y);
            }
        }
        // Add buttons (layer 2)
        for (Preset.Button b:p.buttons){
            if (!"panel".equals(b.type)){
                FloatingButtonView fb=new FloatingButtonView(this,b,false);
                root.addView(fb, new FrameLayout.LayoutParams(b.size,b.size));
                fb.setX(b.x); fb.setY(b.y);
            }
        }
        startForeground(1, buildNotification());
    }
    private Notification buildNotification(){
        if (Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CH,"Overlay HUD", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        PendingIntent toggle = PendingIntent.getBroadcast(this,0,new Intent(this,ToggleReceiver.class).setAction(ToggleReceiver.ACTION_TOGGLE), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent ime = PendingIntent.getBroadcast(this,1,new Intent(this,ToggleReceiver.class).setAction(ToggleReceiver.ACTION_IME), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this,CH).setContentTitle("Overlay HUD activo").setContentText("HUD visible").setSmallIcon(android.R.drawable.ic_media_play).addAction(new NotificationCompat.Action(0,"Mostrar/Ocultar",toggle)).addAction(new NotificationCompat.Action(0,"Teclados",ime)).setOngoing(true).build();
    }
    public static void toggleVisibility(){ if (root==null) return; visible=!visible; root.setAlpha(visible?1f:0f); root.setClickable(!visible); }
    public static void showImePicker(Context c){ Intent i=new Intent(android.provider.Settings.ACTION_INPUT_METHOD_SETTINGS); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); }
    @Nullable @Override public IBinder onBind(Intent intent){ return null; }
    @Override public void onDestroy(){ try{ if (wm!=null && root!=null) wm.removeView(root); }catch(Exception ignored){} super.onDestroy();}
}

